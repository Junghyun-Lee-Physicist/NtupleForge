from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'WJetsToLNu_TuneCP5_amcatnloFXFX'
config.General.transferOutputs = True
config.General.workArea = 'CPV2017UL_MC_Validation'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.scriptExe = 'crab/crab_script.py'
config.JobType.psetName = 'crab/PSet.py'
config.JobType.scriptArgs = []
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['slimmedNtuple.root']
config.JobType.maxMemoryMB = 2500
config.JobType.maxJobRuntimeMin = 600
config.JobType.inputFiles = ['script/run_postproc.py', 'modules/topCPVCategorizer.py', 'modules/jetsMETcut.py', 'modules/nanoaod_branch_access.py', 'modules/noop.py', 'branches/branch_CPV_Run2_MC.txt', 'crabConfig/config_CPV2017UL_MC.yaml', 'crab_args.txt']
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/junghyun/CPV2017UL_MC_Validation'
config.Data.inputDataset = '/WJetsToLNu_TuneCP5_13TeV-amcatnloFXFX-pythia8/RunIISummer20UL17NanoAODv9-106X_mc2017_realistic_v9-v2/NANOAODSIM'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'WJetsToLNu_TuneCP5_amcatnloFXFX'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
