#ifndef SSBGENCATEGORIZER_H
#define SSBGENCATEGORIZER_H

// =============================================================================
//  SSBGenCategorizer
//  -----------------------------------------------------------------------------
//  NanoAOD-based replacement for the GenPar() method of the legacy MiniAOD
//  SSBAnalyzer. Reconstructs a parton-level family tree from the GenPart
//  collection of a CMS NanoAOD file and produces channel-classification
//  variables (Channel_Idx, Channel_Idx_Final, Channel_Jets, ...).
//
//  Framework compatibility
//  -----------------------
//  - Mirrors the Analysis class pattern of the SSB framework:
//        * TChain + TTreeReader
//        * dynamic branch loading from a branchlist text file
//        * interface/ + src/ separation
//        * std::unordered_map<string, unique_ptr<TTreeReaderValue/Array>> storage
//  - Does NOT depend on Analysis.h / SSBCorrections.h / SSBCPVCalc.h.
//    Selection, JEC, and lepton SF are not needed for generator-level
//    categorization, so this class is fully standalone.
//  - Can later be merged into Analysis::Loop() by instantiating SSBGenCategorizer
//    and calling Process(reader) inside the existing event loop.
//
//  Author: based on SSBAnalyzer::GenPar (S. Ha, S. Lee, S. Choi)
// =============================================================================

#include <vector>
#include <array>
#include <string>
#include <memory>
#include <unordered_map>
#include <cstdint>

#include <TChain.h>
#include <TFile.h>
#include <TTree.h>
#include <TTreeReader.h>
#include <TTreeReaderValue.h>
#include <TTreeReaderArray.h>
#include <TLorentzVector.h>

// -----------------------------------------------------------------------------
//  GenPart_statusFlags bit definitions (NanoAODv9 documentation)
// -----------------------------------------------------------------------------
namespace SSBGenStatusBit {
    constexpr int isPrompt                          = 1 << 0;
    constexpr int isDecayedLeptonHadron             = 1 << 1;
    constexpr int isTauDecayProduct                 = 1 << 2;
    constexpr int isPromptTauDecayProduct           = 1 << 3;
    constexpr int isDirectTauDecayProduct           = 1 << 4;
    constexpr int isDirectPromptTauDecayProduct     = 1 << 5;
    constexpr int isDirectHadronDecayProduct        = 1 << 6;
    constexpr int isHardProcess                     = 1 << 7;
    constexpr int fromHardProcess                   = 1 << 8;
    constexpr int isHardProcessTauDecayProduct      = 1 << 9;
    constexpr int isDirectHardProcessTauDecayProduct= 1 << 10;
    constexpr int fromHardProcessBeforeFSR          = 1 << 11;
    constexpr int isFirstCopy                       = 1 << 12;
    constexpr int isLastCopy                        = 1 << 13;
    constexpr int isLastCopyBeforeFSR               = 1 << 14;
}

// -----------------------------------------------------------------------------
//  GenCatResult — one struct per event
// -----------------------------------------------------------------------------
struct GenCatResult {
    // Event-level flag
    bool isSignal = false;            // true iff t AND tbar (last copy) present

    // 12-slot ttbar selection (indices into GenPart_*; -1 if absent)
    //   [0,1]   proton, proton          (NanoAOD does not store -> -1)
    //   [2]     t          [3]  tbar
    //   [4]     W+         [5]  b
    //   [6]     W-         [7]  bbar
    //   [8,9]   W+ daughters
    //   [10,11] W- daughters
    std::array<int, 12> selectedIdx{};

    // Variable-length saved-particle list (Signal: 12 entries, Bkg: variable)
    std::vector<int>   genPar_idx;
    std::vector<int>   genPar_pdgId;
    std::vector<int>   genPar_status;
    std::vector<float> genPar_pt;
    std::vector<float> genPar_eta;
    std::vector<float> genPar_phi;
    std::vector<float> genPar_mass;
    std::vector<float> genPar_energy;     // computed from pt/eta/mass (legacy GenPar branch)
    std::vector<int>   genPar_mom1Idx;
    std::vector<int>   genPar_mom2Idx;
    std::vector<int>   genPar_dau1Idx;
    std::vector<int>   genPar_dau2Idx;
    std::vector<int>   genPar_nMom;
    std::vector<int>   genPar_nDau;
    int                genPar_count = 0;

    // Convenience kinematics for top quarks (parton-level last copy)
    float genTop_pt    = -999.f, genTop_eta    = -999.f;
    float genTop_phi   = -999.f, genTop_energy = -999.f;
    float genAnTop_pt  = -999.f, genAnTop_eta  = -999.f;
    float genAnTop_phi = -999.f, genAnTop_energy = -999.f;

    // Channel classification
    int channel_idx           = 0;
    int channel_idx_final     = 0;
    int channel_lepton        = 0;
    int channel_lepton_final  = 0;
    int channel_jets          = 0;
    int channel_jets_abs      = 0;

    // Tau-secondary tagging (built from GenDressedLepton_hasTauAnc)
    int channel_tau_lepton    = 0;    // # of GenDressedLepton with hasTauAnc==1
    int channel_visible_tau   = 0;    // # of GenVisTau (hadronic tau)

    // -------------------------------------------------------------------------
    // GenJet collection (mirrors SSBAnalyzer::GenJet())
    // -------------------------------------------------------------------------
    std::vector<float> genJet_pt;
    std::vector<float> genJet_eta;
    std::vector<float> genJet_phi;
    std::vector<float> genJet_mass;
    std::vector<float> genJet_energy;        // computed from pt/eta/mass
    std::vector<int>   genJet_partonFlavour;
    std::vector<int>   genJet_hadronFlavour; // 5=b, 4=c, 0=light (NanoAOD ghost clustering)
    int                genJet_count = 0;

    // -------------------------------------------------------------------------
    // GenMET (mirrors SSBAnalyzer::GenMET())
    // -------------------------------------------------------------------------
    float genMET_pt  = -999.f;
    float genMET_phi = -999.f;

    // -------------------------------------------------------------------------
    // Ghost B-hadron / B-jet  (mirrors SSBAnalyzer ghost-B section)
    // GenBJet  = AK4 GenJet with hadronFlavour==5
    // GenBHad  = corresponding b-quark in GenPart (last copy, from-top)
    // -------------------------------------------------------------------------
    std::vector<float> genBJet_pt;
    std::vector<float> genBJet_eta;
    std::vector<float> genBJet_phi;
    std::vector<float> genBJet_energy;

    std::vector<float> genBHad_pt;
    std::vector<float> genBHad_eta;
    std::vector<float> genBHad_phi;
    std::vector<float> genBHad_energy;
    std::vector<int>   genBHad_fromTopWeakDecay; // 1 if mother chain reaches top, 0 otherwise
    std::vector<int>   genBHad_flavour;          // signed pdgId (+5 / -5)
    int                genBJet_count = 0;
    int                genBHad_count = 0;

    // -------------------------------------------------------------------------
    // PSWeights — NanoAOD's parton-shower weights (ISR/FSR variations).
    // These are NOT the same as the bfragWgtProducer weights used in MiniAOD
    // (B-fragmentation systematic). See README/PPT for details.
    //
    //   PSWeight[0] = ISR up   (ISR=2, FSR=1)
    //   PSWeight[1] = FSR up   (ISR=1, FSR=2)
    //   PSWeight[2] = ISR down (ISR=0.5, FSR=1)
    //   PSWeight[3] = FSR down (ISR=1, FSR=0.5)
    // -------------------------------------------------------------------------
    float psWeight_ISR_up   = 1.f;
    float psWeight_FSR_up   = 1.f;
    float psWeight_ISR_down = 1.f;
    float psWeight_FSR_down = 1.f;
    int   psWeight_n        = 0;
};

// -----------------------------------------------------------------------------
//  SSBGenCategorizer — main class
// -----------------------------------------------------------------------------
class SSBGenCategorizer {
public:
    // -------------------------------------------------------------------------
    // Construction modes
    // -------------------------------------------------------------------------

    /// Mode A: standalone driver. Builds its own TTreeReader from the chain
    /// and registers the (hardcoded) list of NanoAOD branches it needs.
    SSBGenCategorizer(TChain* chain,
                      const std::string& outputName,
                      const std::string& seDirName = "",
                      Long64_t maxEvents = -1);

    /// Mode B: as a plug-in. The caller provides an already-set-up TTreeReader
    /// (typically from Analysis::fReader) and a branch map (Analysis::*Vectors).
    /// In this mode the class does NOT own the reader or branches, and Loop()
    /// becomes a no-op — use ProcessEvent() inside the host's event loop.
    SSBGenCategorizer();

    ~SSBGenCategorizer();

    SSBGenCategorizer(const SSBGenCategorizer&) = delete;
    SSBGenCategorizer& operator=(const SSBGenCategorizer&) = delete;

    // -------------------------------------------------------------------------
    // Plug-in attachment (Mode B)
    // -------------------------------------------------------------------------

    /// Attach external branch maps owned by the host Analysis instance.
    /// The pointers given here must remain valid for the lifetime of this
    /// instance. After attachExternal(), call ProcessEvent() inside the host
    /// event loop.
    void AttachExternal(
        std::unordered_map<std::string, std::unique_ptr<TTreeReaderValue<UInt_t>>>* uintSingles,
        std::unordered_map<std::string, std::unique_ptr<TTreeReaderValue<Float_t>>>* floatSingles,
        std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<Float_t>>>* floatVectors,
        std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<Int_t>>>* intVectors,
        std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<Bool_t>>>* boolVectors,
        std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<UChar_t>>>* ucharVectors);

    // -------------------------------------------------------------------------
    // Output booking
    // -------------------------------------------------------------------------

    /// Create / open the output ROOT file and book the GenCat TTree.
    /// Called automatically by Mode-A constructor. Call manually in Mode B
    /// if you want the categorizer to write its own tree.
    void BookOutput();

    // -------------------------------------------------------------------------
    // Main loop / per-event entry points
    // -------------------------------------------------------------------------

    /// Mode A: run over the chain.
    void Loop();

    /// Mode B: process one event using whichever branch map is active
    /// (internal or external). Fills result_, optionally fills the tree.
    const GenCatResult& ProcessEvent();

    /// Latest result (after ProcessEvent).
    const GenCatResult& Result() const { return result_; }

    // -------------------------------------------------------------------------
    // Query helpers (callable after ProcessEvent)
    // -------------------------------------------------------------------------

    /// True if any GenDressedLepton has hasTauAnc==true.
    bool HasTauSecondaryLepton() const;

    /// GenPart indices of W daughters that are e or mu (not tau).
    std::vector<int> PromptChargedLeptonsFromW() const;

    /// Print a one-line summary of the most-recent event.
    void DumpEvent(std::ostream& os) const;

private:
    // -------------------------------------------------------------------------
    // Branch access — supports two modes
    // -------------------------------------------------------------------------

    bool ownReader_ = false;                // true if Mode A
    std::unique_ptr<TTreeReader> reader_;   // owned in Mode A, null in Mode B

    // Either we own these (Mode A) or borrow them (Mode B)
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderValue<UInt_t>>>*  uintSingles_  = nullptr;
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderValue<Float_t>>>* floatSingles_ = nullptr;
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<Float_t>>>* floatVectors_ = nullptr;
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<Int_t>>>*   intVectors_   = nullptr;
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<Bool_t>>>*  boolVectors_  = nullptr;
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<UChar_t>>>* ucharVectors_ = nullptr;

    // Backing storage for Mode A
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderValue<UInt_t>>>   ownUintSingles_;
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderValue<Float_t>>>  ownFloatSingles_;
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<Float_t>>>  ownFloatVectors_;
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<Int_t>>>    ownIntVectors_;
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<Bool_t>>>   ownBoolVectors_;
    std::unordered_map<std::string, std::unique_ptr<TTreeReaderArray<UChar_t>>>  ownUcharVectors_;

    // -------------------------------------------------------------------------
    // Initial setup (Mode A)
    // -------------------------------------------------------------------------

    /// Register the hardcoded set of NanoAOD branches this class needs.
    /// Called automatically by the Mode-A constructor. Not used in Mode B
    /// (which gets its branches from the host Analysis instance).
    void RegisterBranches();

    // -------------------------------------------------------------------------
    // Per-event pipeline
    // -------------------------------------------------------------------------

    GenCatResult result_;
    std::vector<std::vector<int>> daughters_;

    void ClearState();
    void BuildDaughterMap();
    bool FindTopAntiTop();
    int  FindLastDaughter(int parent, int targetPdg) const;
    std::pair<int,int> WDaughters(int wIdx) const;
    void FillSignalSelection();
    void FillBackgroundSelection();
    void PushGenPar(int idx, int mom1, int mom2, int dau1, int dau2);
    void ComputeChannelDirect();
    void ComputeChannelFinal();
    void ComputeChannelJets();

    // New: collections that mirror the MiniAOD GenJet, GenMET, and ghost-B
    // sections, plus PSWeight for shower systematics.
    void ProcessGenJets();
    void ProcessGenMET();
    void ProcessGenBHadrons();
    void ProcessPSWeights();

    /// Walk parent chain of a GenPart and check if any ancestor is a top.
    /// Used to decide GenBHad_FromTopWeakDecay.
    bool IsAncestorTop(int idx, int maxDepth = 100) const;

    /// Find the GenPart index of a b-quark (last copy) closest in ΔR
    /// to a given (eta, phi). Returns -1 if none within maxDR.
    int FindNearestBQuark(float eta, float phi, float maxDR = 0.4f) const;

    // -------------------------------------------------------------------------
    // Output
    // -------------------------------------------------------------------------

    std::string outputName_;
    std::string seDirName_;
    Long64_t    maxEvents_ = -1;

    TFile*  fout_   = nullptr;
    TTree*  outTree_ = nullptr;

    // Branch buffers
    Bool_t   out_isSignal_;
    Int_t    out_selectedIdx_[12];
    Int_t    out_genPar_count_;
    std::vector<Int_t>   out_genPar_idx_;
    std::vector<Int_t>   out_genPar_pdgId_;
    std::vector<Int_t>   out_genPar_status_;
    std::vector<Float_t> out_genPar_pt_;
    std::vector<Float_t> out_genPar_eta_;
    std::vector<Float_t> out_genPar_phi_;
    std::vector<Float_t> out_genPar_mass_;
    std::vector<Float_t> out_genPar_energy_;
    std::vector<Int_t>   out_genPar_mom1Idx_;
    std::vector<Int_t>   out_genPar_mom2Idx_;
    std::vector<Int_t>   out_genPar_dau1Idx_;
    std::vector<Int_t>   out_genPar_dau2Idx_;
    std::vector<Int_t>   out_genPar_nMom_;
    std::vector<Int_t>   out_genPar_nDau_;
    Float_t out_genTop_pt_, out_genTop_eta_, out_genTop_phi_, out_genTop_energy_;
    Float_t out_genAnTop_pt_, out_genAnTop_eta_, out_genAnTop_phi_, out_genAnTop_energy_;
    Int_t   out_channel_idx_, out_channel_idx_final_;
    Int_t   out_channel_lepton_, out_channel_lepton_final_;
    Int_t   out_channel_jets_, out_channel_jets_abs_;
    Int_t   out_channel_tau_lepton_, out_channel_visible_tau_;

    // -- New buffers for GenJet collection --
    Int_t                out_genJet_count_;
    std::vector<Float_t> out_genJet_pt_;
    std::vector<Float_t> out_genJet_eta_;
    std::vector<Float_t> out_genJet_phi_;
    std::vector<Float_t> out_genJet_mass_;
    std::vector<Float_t> out_genJet_energy_;
    std::vector<Int_t>   out_genJet_partonFlavour_;
    std::vector<Int_t>   out_genJet_hadronFlavour_;

    // -- New buffers for GenMET --
    Float_t out_genMET_pt_;
    Float_t out_genMET_phi_;

    // -- New buffers for Ghost B-jet / B-hadron --
    Int_t                out_genBJet_count_;
    Int_t                out_genBHad_count_;
    std::vector<Float_t> out_genBJet_pt_;
    std::vector<Float_t> out_genBJet_eta_;
    std::vector<Float_t> out_genBJet_phi_;
    std::vector<Float_t> out_genBJet_energy_;
    std::vector<Float_t> out_genBHad_pt_;
    std::vector<Float_t> out_genBHad_eta_;
    std::vector<Float_t> out_genBHad_phi_;
    std::vector<Float_t> out_genBHad_energy_;
    std::vector<Int_t>   out_genBHad_fromTopWeakDecay_;
    std::vector<Int_t>   out_genBHad_flavour_;

    // -- New buffers for PSWeight (shower systematics) --
    Float_t out_psWeight_ISR_up_;
    Float_t out_psWeight_FSR_up_;
    Float_t out_psWeight_ISR_down_;
    Float_t out_psWeight_FSR_down_;
    Int_t   out_psWeight_n_;

    void SyncOutputBuffers();

    // -------------------------------------------------------------------------
    // Branch-access helpers — return pointers into whichever map is active
    // -------------------------------------------------------------------------

    const TTreeReaderValue<UInt_t>*  GetUIntSingle (const std::string& name) const;
    const TTreeReaderValue<Float_t>* GetFloatSingle(const std::string& name) const;
    const TTreeReaderArray<Float_t>* GetFloatVector(const std::string& name) const;
    const TTreeReaderArray<Int_t>*   GetIntVector  (const std::string& name) const;
    const TTreeReaderArray<Bool_t>*  GetBoolVector (const std::string& name) const;
    const TTreeReaderArray<UChar_t>* GetUCharVector(const std::string& name) const;
};

#endif // SSBGENCATEGORIZER_H
