from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'ttbar_SemiLeptonic_v1'
config.General.requestName = 'ttbar_SemiLeptonic_v1_TTbar_SemiLep'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.scriptExe = 'crab/crab_script.py'
config.JobType.psetName = 'crab/PSet.py'
config.JobType.maxJobRuntimeMin = 600
config.JobType.pluginName = 'Analysis'
config.JobType.scriptArgs = []
config.JobType.inputFiles = ['scripts/run_postproc.py', 'modules', 'branches', 'crab_args.txt']
config.JobType.maxMemoryMB = 2500
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/TTToSemiLeptonic_TuneCP5_13TeV-powheg-pythia8/RunIISummer20UL17NanoAODv9-106X_mc2017_realistic_v9-v1/NANOAODSIM'
config.Data.publication = False
config.Data.outLFNDirBase = '/store/user/junghyun/'
config.Data.unitsPerJob = 50000
config.Data.splitting = 'EventAwareLumiBased'
config.Data.outputDatasetTag = 'TTbar_SemiLep'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
